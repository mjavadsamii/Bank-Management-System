#include "Loan.h"
#include "../Account/Account.h"
#include <iostream>

class Account;

Loan::Loan(Customer & customer,int numofloan , double amount, double interestRate, int term)
:lo_customer(&customer), amount(amount), numofloan(numofloan)// interestRate(interestRate), term(term), installmentAmount(0)
{
    this->installmentAmount = calculateInstallmentAmount();
    //linking account to the loan by chosing 
    // to link to the lo_account 
   lo_AllLoans[customer.get_UserName()][std::to_string(numofloan)]["Borrower"] = customer.get_Name() + customer.get_Family();
   lo_AllLoans[customer.get_UserName()][std::to_string(numofloan)]["Amount"] =std::to_string( amount);
   lo_AllLoans[customer.get_UserName()][std::to_string(numofloan)]["IntersetRate"]=std::to_string(interestRate);
   lo_AllLoans[customer.get_UserName()][std::to_string(numofloan)]["numofInstallmentpaid"] = std::to_string(numofInstallmentpaid);
   lo_AllLoans[customer.get_UserName()][std::to_string(numofloan)]["installmentAmount "]= std::to_string(installmentAmount );
   // this is for test
   cout<<lo_AllLoans[customer.get_UserName()][std::to_string(numofloan)];

   // store loans in file;
   // store loans in customer 
   customer.loans[numofloan-1] = this;


}


/**Loan::Loan(Customer & customer)
:lo_customer(&customer), amount(0), interestRate(0), term(0), installmentAmount(0)
{
    //linking account to the loan by chosing 
    // to link to the lo_account 
}**/


double Loan::calculateInstallmentAmount() const {
    double interest = amount * interestRate;
    double totalAmount = amount + interest;
    return totalAmount / term;
}

void Loan::deductInstallmentFromAccount() {
    std::cout << "Deducting installment amount from customer's account." << std::endl;
    lo_account->withdraw(calculateInstallmentAmount());
    this->numofInstallmentpaid++;
    Loan::lo_AllLoans[this->lo_customer->get_UserName()][std::to_string(numofloan)]["numofInstallmentpaid"] = std::to_string(numofInstallmentpaid);
    

}
void Loan::Employee_verifying (Employee * employee)
{
    this->lo_verify_by_customer = true;
    this->verify_by = employee;
}
void Loan::Admin_verifying ()
{
    this->lo_verify_by_admin = true;
}
bool Loan::ReloadFile()
{
     if (lo_AllLoans.is_null())
    {   cout<<"check null if ";
        fstream AllLoansFILE("./AllLoansFILE.json");
        if (AllLoansFILE.is_open())//AllAccountsFILE.good())
        {   cout<<"check good if ";
            cout<<"buffer : " <<AllLoansFILE.rdbuf();
            //auto lg_AllAccounts = json::parse(AllLoansFILE);
            AllLoansFILE.close();
            return true;
        }
    }
    return false;
}
void Loan::remove()
{
    this->lo_customer->loans[numofloan] = nullptr;
    // and another
    this->~Loan();
}
bool Loan::get_verify_by_customer()
{
    return this->lo_verify_by_customer;
}
bool Loan::get_verify_by_admin()
{
    return this->lo_verify_by_admin;
}
int main()
{  
    Loan::ReloadFile();
    Customer customer("Erfan","Nouri",1234);
    Loan Loan1(customer ,1,10 , 40,100);
	return 0;
}