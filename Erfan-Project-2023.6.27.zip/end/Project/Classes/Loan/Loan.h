#ifndef LOAN_H
#define LOAN_H

#include <string>
#include "../Account/Account.h"
#include "../Customer/Customer.h"
#include "../Employee/Employee.h"
using json = nlohmann::json;
class Employee;
class Customer;
class Account;

class Loan {
private:
	Customer * lo_customer;
    Account * lo_account;
    double amount;
    double interestRate;
    int term; // in month // term for what 
    double installmentAmount;
    int numofInstallmentpaid{};
    bool lo_verify_by_customer = false ;
    bool lo_verify_by_admin = false;
    Employee * verify_by ;
    int numofloan;//number of loans it must be between 1 to 3;

public:
    static json lo_AllLoans;
    Loan(Customer &customer,int numofloan, double amount, double interestRate, int term);
    //Loan(Customer &customer);

    double calculateInstallmentAmount() const;
    void deductInstallmentFromAccount();
    void Employee_verifying (Employee * employee);
    void Admin_verifying ();
    static bool ReloadFile();
    void remove ();
    bool get_verify_by_customer();
    bool get_verify_by_admin();
};

#endif // LOAN_H
