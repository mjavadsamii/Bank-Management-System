#ifndef LOGIN_H
#define LOGIN_H

#include <string>
#include <iostream>
#include <fstream>
#include "../nlohmann/single_include/nlohmann/json.hpp"
using namespace std;

using json = nlohmann::json;
class Login 
{
    private:
        string lg_UserName;
        // do not need to store exactly password 
        //string login_Password;
        string lg_HashedPassword ;
        static json lg_AllAccounts;
    public :
    Login( const string & UserName ,const string & Password);
    bool Authenticate(const string& UserName, const string& Password);
    bool Logout();
    string Hashing(const string& Password);
    // only we need hashing
    //string DeHashing(const string& HashedPassword);  
    bool checkUserName(const string & UserName); 
    string get_UserName();// for encapuslation and does not them friend class
    string get_HPassword();
    bool change_Password();// for changing password ;
    
};


#endif