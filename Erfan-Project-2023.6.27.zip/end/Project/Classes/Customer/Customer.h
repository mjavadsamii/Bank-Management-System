#ifndef CUSTOMER_H
#define CUSTOMER_H
#include "../UserInfo/UserInfo.h"
#include <string>
#include <vector>
#include "../Account/Account.h"
#include "../Transaction/Transaction.h"
#include"../Loan/Loan.h"
#include <map>

class Account;
class Transaction;
class Loan;

class Customer : public UserInfo 
{
private:
    
    bool Employee_verify = false; // for verifying user account by employee

public:
    // this vector must be private for encapuslation 
    std::vector<Account*> accessibleAccounts;
	static std::map<std::string, Customer*> All_Customers;
    Loan * loans[3];// maximum can take three loans //
	Customer(const std::string& name, const std::string& family, const int ID);
	Customer();
    
	void addAccessibleAccount(Account* account);
    void removeAccessibleAccount(Account* account);
    void viewAccessibleAccounts() const;
    void performTransaction(int sourceAccount, int destinationAccount, double amount) const;
    void viewAccountTransactions(Account account) const ;
    void Verify();
    void Discredit();
	// userinfo function handle this 
    //std::string get_UserName()const ;
    //std::string get_Name() const;
    //std::string get_Family() const;

};

#endif // CUSTOMER_H
