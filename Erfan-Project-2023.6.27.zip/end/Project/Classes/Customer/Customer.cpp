#include "Customer.h"
#include <iostream>
#include <vector>
#include "../Transaction/Transaction.h"
#include "../UserInfo/UserInfo.h"

std::map<std::string, Customer*> Customer::All_Customers;

Customer::Customer(const std::string& name, const std::string& family, const int ID) : UserInfo(name, family, ID) {}
Customer::Customer() : UserInfo(" ", " ", 0) {}

void Customer::addAccessibleAccount(Account* account) {
    accessibleAccounts.push_back(account);
}

void Customer::removeAccessibleAccount(Account* account) {
    for (auto it = accessibleAccounts.begin(); it != accessibleAccounts.end(); ++it) {
        if ((*it)->get_accountNum() == account->get_accountNum()) {
            accessibleAccounts.erase(it);//nice 
            (*it)->~Account();
            return;
        }
    }
    std::cout << "Account number not found in accessible accounts." << std::endl;
}

void Customer::viewAccessibleAccounts() const {
    std::cout << "Accessible Accounts for Customer " << get_Name() << ":" << std::endl;
    for (const auto& account : accessibleAccounts) {
        std::cout << account << std::endl;
    }
}

void Customer::performTransaction(int sourceAccount, int destinationAccount, double amount) const {
    bool sourceAccountAccessible = false;
    bool destinationAccountAccessible = false;

    for (const auto& account : accessibleAccounts) {
        if (account->get_accountNum() == sourceAccount) {
            sourceAccountAccessible = true;
        }

        if (account->get_accountNum() == destinationAccount) {
            destinationAccountAccessible = true;
        }

        if (sourceAccountAccessible && destinationAccountAccessible) {
            // Perform the transaction logic here
            std::cout << "Performing transaction:" << std::endl;
            std::cout << "Source Account: " << sourceAccount << std::endl;
            std::cout << "Destination Account: " << destinationAccount << std::endl;
            std::cout << "Amount: " << amount << std::endl;
            std::cout << "Transaction successful!" << std::endl;
            return;
        }
    }

    std::cout << "Transaction failed: Invalid account(s)." << std::endl;
}

void Customer::viewAccountTransactions(Account account) const
 {
    std::cout << "Transaction History for Account " << account.get_accountNum() << ":" << std::endl;

    // i think its better to store all transactions ID in Account object as all transactions of account 
    // and use show transaction
	
    for ( auto& transactionID : account.ac_allTransactions) {
        //if (transaction.accountNumber == accountNumber) // no need to this
            Transaction::get_Transaction(transactionID);
            Transaction::get_Transaction(transactionID).print();
            Transaction::get_Transaction(transactionID).Tr_delete();
            
            // Print other transaction details
    }
        
    
}


// no need to this function 
//std::string Customer::get_UserName()  {
  //  return UserInfo::get_UserName();
//}
// no need to this fucntion methode of userinfo do it 
//std::string Customer::get_Name() const {
  //  return UserInfo::get_Name();
//}
// and also no need to this 
//std::string Customer::get_Family() const {
  //  return UserInfo::get_Family();
//}

void Customer::Verify() 
{
    this->Employee_verify = true;
}

void Customer::Discredit() {
    Employee_verify = false;
}

int main()
{   
    Customer Customer1("Ali","Zamani",12345);
	return 0;
}