#include "Account.h"
#include <iostream>
#include <stdlib.h>
#include <time.h>

json Account::ac_AllTransactionsOfthisAcc;


Account::Account(Customer & customer ) : ac_Owner(&customer), ac_balance(0)
{
    srand ( time (0));
    long long ac_accountNumber = rand()%100000000000;

        if (ac_AllTransactionsOfthisAcc.is_null())
        {
            string TempFilePath = "./"+ std::to_string(ac_Owner->get_ID() ) + ".JSON";
            ifstream accTransactionsFILE(TempFilePath.c_str());
            if (accTransactionsFILE.good())
            {
                ac_AllTransactionsOfthisAcc = json::parse(accTransactionsFILE);
                accTransactionsFILE.close();
            }
        }
};

Account::Account() : ac_balance(0)
{
    srand ( time (0));
    long long ac_accountNumber = rand()%100000000000;

        if (ac_AllTransactionsOfthisAcc.is_null())
        {
            string TempFilePath = "./"+ std::to_string(ac_Owner->get_ID() ) + ".JSON";
            ifstream accTransactionsFILE(TempFilePath.c_str());
            if (accTransactionsFILE.good())
            {
                ac_AllTransactionsOfthisAcc = json::parse(accTransactionsFILE);
                accTransactionsFILE.close();
            }
        }
};



void Account::deposit(double amount) {
    ac_balance += amount;
}
// this has much better executaion and must focus to handle it 
void Account::withdraw(double amount) {
    if (ac_balance >= amount) {
        ac_balance -= amount;
        
    } else {
        std::cout << "Insufficient balance." << std::endl;
    }
}

void Account::display() const {
    std::cout << "Account Number: " << ac_accountNumber << std::endl;
    std::cout << "Balance: " << ac_balance << std::endl;
}

int Account::get_accountNum()const { return ac_accountNumber;}

Account * Account::find_Account ( int AccountNumber )
{
    if (ac_AllTransactionsOfthisAcc.contains(std::to_string(AccountNumber)))
    {
            //make an temporary object 
            //i dont know what should i do 
            // we can at first running up program insert every accounts and customers and ... to the map variable 
            // or we can do  when we need this object at first check in the Json file to see that this abject like 
            // acoount is there exist ? or no 
            // if exist we can make and object with those information and use it 
            //but it does not safe and good job
            //Account FoundAccount =  new Account();//with informations that in the file
            // i define default constructor of Account to cut error temporary 
            // but it musnt be such that 
            //we should find customre account and give it to Account constructor
            //ad_AllAccounts[AccountNumber] = &FoundAccount;
            //return ad_AllAccounts[AccountNumber] ;
    }
    else 
    {
        cout<<"There is no account with this number \n";
    }
}
bool Account::get_status()const
{
    return this->ac_status;
}
string Account::get_type()const
{
    return this->ac_Type;
}
Customer * Account::get_customer()
{
    return this->ac_Owner;
}
/**
CurrentAccount::CurrentAccount(int accountNumber) : Account(accountNumber) {}

void CurrentAccount::withdraw(double amount) {
    // No specific withdrawal restrictions for current account
    Account::withdraw(amount);
}

LongTermDepositAccount::LongTermDepositAccount(int accountNumber, int term)
    : Account(accountNumber), term(term) {}

void LongTermDepositAccount::display() const {
    Account::display();
    std::cout << "Term: " << term << " months" << std::endl;
}

ShortTermDepositAccount::ShortTermDepositAccount(int accountNumber, int term)
    : Account(accountNumber), term(term) {}

void ShortTermDepositAccount::display() const {
    Account::display();
    std::cout << "Term: " << term << " months" << std::endl;
}**/
int main()
{
	return 0;
}