#ifndef ACCOUNT_H
#define ACCOUNT_H

#include "../Customer/Customer.h"
#include "../nlohmann/single_include/nlohmann/json.hpp"
#include "../Loan/Loan.h"
#include <vector>
using std::vector;

class Customer;
class Loan;

class Account {
protected:
    int ac_accountNumber;
    double ac_balance;
    Customer  *ac_Owner;
    bool ac_status =  false;// for checiinkg active or nonavtive of account 
    string ac_Type ;// because we dont need to define another type account class 
    Loan * ac_Loan;
    
public:
    // vector must be private for capsulation but i need to be public in customer for viewalltransactionss
    vector <int > ac_allTransactions;
    static json ac_AllTransactionsOfthisAcc;
    static map <int , Account *> ad_AllAccounts; 
    Account(Customer & customer);
    Account ();
    void deposit(double amount);// this is ok 
    void withdraw(double amount);
    void display() const;
    int get_accountNum()const;
    int get_balance() const;
    static Account* find_Account (int AccountNumber );
    static void find_account_from_json_file_and_make_obj(int AccountNumber);// this name must be change 
    //this function is used to find account function to find account from json file and make longtime obj and return this ponter
    bool get_status()const;
    string get_type()const;
    Customer * get_customer();

};
// we msut define this in anothe file ;
/**
class CurrentAccount : public Account {
public:
    CurrentAccount(int accountNumber);
    void withdraw(double amount) ;
};
/** 
class LongTermDepositAccount : public Account {
private:
    int term; // in months

public:
    LongTermDepositAccount(int accountNumber, int term);
    void display() const ;
};**/
// :/
/**
class ShortTermDepositAccount : public Account {
private:
    int term; // in months

public:
    ShortTermDepositAccount(int accountNumber, int term);
    void display() const ;
};**/

#endif // ACCOUNT_H
