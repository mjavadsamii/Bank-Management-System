#ifndef JONINFO_H
#define JONINFO_H

class JobInfo 
{
    private :
        int ji_TimeOfWork;
        int ji_Salary;
    public :
       // JobInfo();// default constructor for what ? 
        JobInfo(int TimeOfWork = 0 , int Salary =0 ) ; //int TimeOfWork , int Salary )
        // another function that we need 
        // and also getter and setter 
        // we should to define that in .cpp 
        void set_Time(int Time);
        void set_Salary(int Salary);
        int get_Time();
        int get_Salary();
};

#endif