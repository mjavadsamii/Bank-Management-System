#include "JobInfo.h"
#include <iostream>
using std::cout;
class JobInfo;
// this class for base class that employee and admin are inherited from this beacuse they have job 
JobInfo::JobInfo(int TimeOfWork  , int Salary )
{
    ji_TimeOfWork = TimeOfWork ;
    ji_Salary = Salary;
}
void JobInfo::set_Time(int Time)
{
    this->ji_TimeOfWork = Time;
}
void JobInfo::set_Salary(int Salary)
{
    this->ji_Salary = Salary;
}
int JobInfo::get_Time()
{
    return this->ji_TimeOfWork;
}
int JobInfo::get_Salary()
{
    return this->ji_Salary;
}
int main ()
{
    JobInfo JobInfo1(8,54000000);
    cout<<JobInfo1.get_Time()<<" "<<JobInfo1.get_Salary();
    return 0;
}