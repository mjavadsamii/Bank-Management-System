#include "Admin.h"
//#include "../Employee/Employee.h"
#include "../UserInfo/UserInfo.h"
#include <iostream>
using std::cin;
using std::cout;
map<string , Admin *> Admin::ad_AllAdmins; 
// Constructors
Admin::Admin(std::string name, std::string family, int ID)
    : UserInfo(name, family, ID) {

        ad_AllAdmins[this->get_LoginInfo()->get_UserName()] = this;
}

// Employee management
void Admin::ad_addEmployee( Employee& employee) {
    Employee::em_AllEmployees[employee.get_UserName()] = &employee;
    cout << "Employee added successfully." << std::endl;
}

void Admin::ad_removeEmployee(const Employee& employee) {
   /** auto it = std::find(employees.begin(), employees.end(), employee);
    if (it != employees.end()) {
        employees.erase(it);**/
    if ( Employee::em_AllEmployees.find ( employee.get_UserName()) != Employee::em_AllEmployees.end())
    {
        Employee::em_AllEmployees.erase(employee.get_UserName());

        cout <<"Employee : "<<employee.get_Name()<<" removed successfully." << std::endl;
    } else {
        cout <<"Employee : "<<employee.get_Name()<<" Not found " << std::endl;
    }
}

void Admin::ad_updateEmployee( Employee& employee) {// when we want update customer it must not be a const 

            // i wanna better works for this function 
            int Temp_Salary {};
            int Temp_Time{};
            cout<<"How much salary would prefer to set for him \n";
            cin>>Temp_Salary;
            cout<<"How many time would prefer to set for him/her \n";
            cin>>Temp_Time;
            (Employee::em_AllEmployees[employee.get_UserName()])->set_Salary(Temp_Salary);
            (Employee::em_AllEmployees[employee.get_UserName()])->set_Time(Temp_Salary);
            cout << "Employee updated successfully." << std::endl;
            return;
    
}

// Customer management
void Admin::ad_addCustomer(Customer& customer) {
    Customer::All_Customers[customer.get_UserName()] = &customer;
    std::cout << "Customer added successfully." << std::endl;
}

void Admin::ad_removeCustomer(const Customer& customer) {
    // bebin javad ma darim objective kar mikonim yani objectesho pas midim 
    // pas hatman bayad vojod dashte bashe va niaz be in nist 
    
    delete &customer;
    Customer::All_Customers.erase(customer.get_UserName());
   /** auto it = std::find(customers.begin(), customers.end(), customer);
    if (it != customers.end()) {
        customers.erase(it);
        std::cout << "Customer removed successfully." << std::endl;
    } else {
        std::cout << "Customer not found." << std::endl;
    }**/
}

void Admin::ad_updateCustomer(Customer& customer) {
    // javad benazaram marhake etebar sanji ro bezarim biron in tabe ha
    // mogheii ke gharar object customer sakhteh besheh 

    // this is very important methode 
    // need switch case
    char yesOrNo = 'y';
    string temp;
    int tempnum;
    int numofchose;
    int counter = 0;
    while(yesOrNo == 'y' || yesOrNo == 'Y' || counter!= 3)
    {
        cout<<"Enter your number for your job \n";
        cout<<"1_Edit Name \n";
        cout<<"2_Edit Family \n";
        cout<<"3_Edit ID \n";
        cout<<"4_Edit Password \n"; 
        cout<<"UserName can not changed \n"; 
        cin>>numofchose;
        switch(numofchose)
        {
             case 1 : cout<<"Edit Name : Enter your Name : \n";
                    cin>>temp;
                    customer.set_name(temp);
                    break;
            case 2 : cout<<" Edit Family : Enter Your Family \n";
                    cin>>temp;
                    customer.set_family(temp);
                    break;
            case 3: cout<<" Edit ID : Enter Your ID :\n";
                    cin>>tempnum ;
                    customer.set_ID(tempnum);
            case 4 :customer.get_LoginInfo()->change_Password();
                    break;
        }
        cout<<"For another edit Enter y : yes , n : no \n";
        counter++;
    }
    
    /**for (auto& cust : customers) {
        if (cust.getID() == customer.getID()) {
            cust.setAddress(customer.getAddress());
            std::cout << "Customer updated successfully." << std::endl;
            return;
        }
    }**/
    //std::cout << "Customer not found." << std::endl;
}

// Account management
void Admin::ad_addAccount(Customer & customer ) {
    // for add acount 
    // need to make an account and then ad it 
    Account * newAccount = new Account(customer);
     customer.addAccessibleAccount(newAccount);
    std::cout << "Account added successfully." << std::endl;
}

void Admin::ad_removeAccount(Account& account) {

    if (Account::ac_AllTransactionsOfthisAcc.contains(std::to_string(account.get_accountNum())))
    {
        account.get_customer()->removeAccessibleAccount(&account);
        std::cout << "Account removed successfully." << std::endl;
    }
    else
    {
        std::cout << "Account not found." << std::endl;
    }


    /**auto it = std::find(accounts.begin(), accounts.end(), account);
    if (it != accounts.end()) {
        accounts.erase(it);
        std::cout << "Account removed successfully." << std::endl;
    } else {
        std::cout << "Account not found." << std::endl;
    }**/
}
// no need update account 
// we need methode to do transaction 

/**void Admin::ad_updateAccount( Account& account) {

     if (Account::ac_AllTransactionsOfthisAcc.contains(account.get_accountNum()))
    {
        //int x;// declare number for which changing 
        //cout<<
        //account.changing(x);
    }
    else
    {
        std::cout << "Account not found." << std::endl;
    }


   /** for (auto& acc : accounts) {
        if (acc.getAccountNumber() == account.getAccountNumber()) {
            acc.setBalance(account.getBalance());
            std::cout << "Account updated successfully." << std::endl;
            return;
        }
    }
    std::cout << "Account not found." << std::endl;
}
**/

// Loan management
/**void Admin::ad_addLoan(const Loan& loan) {
    loans.push_back(loan);
    std::cout << "Loan added successfully." << std::endl;
}**/
// we dont need add loan
// we need confirm loan 
bool Admin::ad_confirm_loan(Loan & loan)
{
    if (loan.get_verify_by_customer()== true)
    {
        loan.Admin_verifying();
        cout<<"Your Loan is verified by Admin \n";
        return true;
    }
    else
    {
        cout<<"Your Loan is not verifyed by Employee \n";
        return false;
    }

}
// ok
void Admin::ad_removeLoan( Loan& loan) {
    loan.remove();
    delete &loan;
   // we should think what exacly do this fucntion 

    /**auto it = std::find(loans.begin(), loans.end(), loan);
    if (it != loans.end()) {
        loans.erase(it);
        std::cout << "Loan removed successfully." << std::endl;
    } else {
        std::cout << "Loan not found." << std::endl;
    }**/
}
/**
void Admin::ad_updateLoan(const Loan& loan) {
    for (auto& ln : loans) {
        if (ln.getLoanID() == loan.getLoanID()) {
            ln.setAmount(loan.getAmount());
            std::cout << "Loan updated successfully." << std::endl;
            return;
        }
    }
    std::cout << "Loan not found." << std::endl;
}**/

// Transaction management
// Admin needs some methodes to do transaction like transfer money and lob lob and will write that 
// but i think it must be view all transactions

/**void Admin::addTransaction(const Transaction& transaction) {
    transactions.push_back(transaction);
    std::cout << "Transaction added successfully." << std::endl;
}**/
void Admin::viewAccountTransactions(Account account) const
 {
    std::cout << "Transaction History for Account " << account.get_accountNum() << ":" << std::endl;

    // i think its better to store all transactions ID in Account object as all transactions of account 
    // and use show transaction
	
    for ( auto& transactionID : account.ac_allTransactions) {
        //if (transaction.accountNumber == accountNumber) // no need to this
            Transaction::get_Transaction(transactionID);
            Transaction::get_Transaction(transactionID).print();
            Transaction::get_Transaction(transactionID).Tr_delete();
            
            // Print other transaction details
    }
        
    
}
// what the means update transaction ?
/**void Admin::updateTransaction(const Transaction& transaction) {
    for (auto& tr : transactions) {
        if (tr.getTransactionID() == transaction.getTransactionID()) {
            tr.setAmount(transaction.getAmount());
            std::cout << "Transaction updated successfully." << std::endl;
            return;
        }
    }
    std::cout << "Transaction not found." << std::endl;
}**/

// Search functions
void Admin::ad_EditEmployees(Employee & employee) {
    // Implement the logic to search and display employees
    // based on specific criteria or search parameters
    int salary;
    int time;
    cout<<"How Many Time set work for him/her \n ";
    cin>>time;
    cout<<"How much salary would you set for him/her \n";
    cin>>salary;
    employee.set_Time(time);
    employee.set_Salary(salary);
    //std::cout << "Searching employees..." << std::endl;
    // Implement the search functionality
}

void Admin::ad_searchCustomers(string Name , string Family )
 {
    // Implement the logic to search and display customers
    // based on specific criteria or search parameters
    if (Customer::All_Customers[Name+Family])
    {
        cout<<"Name: "<<Customer::All_Customers[Name+Family]->get_Name()<<"Family : "<<Customer::All_Customers[Name+Family]->get_Family();
        // we neew number to make choice 
        // like int x
        cout<<"what do you wannt";
        int x;
        switch(x)
        {
            //caling somefunction for doing somthings on customer
            case 1 : //Customer::All_Customers[Name+Family]->
            case 2:
            case 3:
                break;
        }
        //Customer::All_Customers[Name+Family]
    }
    else
    {
        cout<<"customer is not found \n ";
    }
   // std::cout << "Searching customers..." << std::endl;
    // Implement the search functionality
}
/**
void Admin::ad_searchTransactions(int TransactionID) {

    if ( Transaction::tr_AllTransactions.contains(std::to_string(tr_transactionID)))
    {
        
    }
    // Implement the logic to search and display transactions
    std::cout << "Searching transactions..." << std::endl;
    // Implement the search functionality
}

void Admin::searchLoans() {
    // Implement the logic to search and display loans
    std::cout << "Searching loans..." << std::endl;
    // Implement the search functionality
}

// Other functions 
// i can not recognize this for what 
void Admin::displayMenu() {
    // Implement the logic to display the menu options
    std::cout << "Displaying menu..." << std::endl;
    // Implement the menu functionality
}**/
int mian()
{
    Admin Admin1("Mohammad","Nouri",12345);
    return 0;
}