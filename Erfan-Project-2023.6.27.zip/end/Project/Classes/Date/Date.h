#ifndef DATE_H
#define DATE_H

#include <string>
using std::string;
class Date {
public:
    Date(int day=0, int month=0, int year=0);
    Date ( string Date );
    int getDay() const;
    int getMonth() const;
    int getYear() const;
    void setDay(int day);
    void setMonth(int month);
    void setYear(int year);
    void printDate() const;
    string date_to_string();

private:
    int day;
    int month;
    int year;
};

#endif  // DATE_H
