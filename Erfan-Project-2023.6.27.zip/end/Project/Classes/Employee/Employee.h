#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
#include <map>
#include "../Customer/Customer.h"
#include "../Account/Account.h"
#include "../Loan/Loan.h"
#include "../JobInfo/JobInfo.h"
#include "../UserInfo/UserInfo.h"

using std::string;
using std::map;

class Loan;
class Customer;
class Account;

class Employee : public UserInfo , public JobInfo 
{
private:
    std::string name;
    std::string family;
    int ID; 

public:
    static std::map < string , Employee *> em_AllEmployees ;
    // Constructor to initialize an Employee object
    Employee(std::string name, std::string family, int ID);
    Employee();
    
    // Getter methods to retrieve employee information
    std::string getName();
    std::string getFamily();
    int getID();
    
    // Methods to manage customers
    void addCustomer( Customer& customer); // Add a customer to the employee's list of customers // it is must not be const 
    void removeCustomer(const Customer& customer); // Remove a customer from the employee's list of customers
    void displayCustomers(); // Display the list of customers associated with the employee
    void verify_Customer (Customer & customer );
    void discredit_Customer(Customer & customer );
    
    // Methods to manage customer accounts
    
    void displayCustomerAccounts(Customer& customer); // Display the accounts associated with a customer
    void Transfer_Money(Account& fromAccount, Account& toAccount, double amount);
    void Deposit_Money (Account& toAccount, double amount);
    void Pick_Up_Money (Account& fromAccount, double amount);
    // instance of this methode it is better to write up methodes 
    //void performTransaction(Account& fromAccount, Account& toAccount, double amount); // Perform a transaction between two accounts
    
    // Methods to manage loan requests
    void approveLoanRequest(Loan& loan); // Approve a loan request
    
    // Methods to retrieve account information
    void getAccountStatus(const Account& account); // Retrieve the status of an account
    
    // Methods to associate and disassociate accounts with customers
    void addAccountToCustomer(Customer& customer); // Associate an account with a customer
   
    void removeAccountFromCustomer( Account & account); // Disassociate an account from a customer
    
    // Method to display transactions for a customer account
    void displayCustomerAccountTransactions( Customer& customer);
};

#endif
