#include "Login.h"
#include <iostream>
#include <fstream>
#include "../nlohmann/single_include/nlohmann/json.hpp"
#include<string>

json Login::lg_AllAccounts;

Login::Login(const string &UserName, const string &Password)
    : lg_UserName(UserName), lg_HashedPassword(Hashing(Password))// nice good 
{
    if (lg_AllAccounts.is_null())
    {   //cout<<"check null if ";
        ifstream AllAccountsFILE("./AllAccountsFILE.json",std::ios::app);
        if (AllAccountsFILE.is_open())//AllAccountsFILE.good())
        {   //cout<<"check good if ";
            //cout<<"buffer : " <<AllAccountsFILE.rdbuf();
            auto lg_AllAccounts = json::parse(AllAccountsFILE);
            AllAccountsFILE.close();
        }
    }
    
    lg_AllAccounts[UserName]["Password"] = lg_HashedPassword;
    // for debuging 
    //cout <<lg_AllAccounts[UserName];
    // for debugin 
    cout<<"your hash password "<<lg_HashedPassword;
    // for debugin 
    //cout<<lg_AllAccounts;

    cout << "Your User account was created.\n";
    cout << "Your username is: " << lg_UserName << '\n';
    cout << "Your password is: " << Password << '\n';

}

bool Login::Authenticate(const string& UserName, const string& Password)
{
    string TempUserName = UserName ;

    if (lg_AllAccounts.contains(TempUserName))
    {
        //cout<<"this is if is ok";
        //cout<<lg_AllAccounts[TempUserName]["Password"];
        cout<<Login::Hashing(Password) ;
        if (Login::Hashing(Password) == lg_AllAccounts[TempUserName]["Password"])
        {
            //cout<<"secend if is  ok ";
            cout << "You logged in.\n";

            return true;
        }
        else
        {
            cout << "Your password is wrong. Please try again.\n";
            return false;
        }
    }

    cout << "Your usernamed was not found. Please sign up or enter the correct username.\n";
    return false;
}

bool Login::Logout()
{
    // Perform logout actions here
    cout << "You logged out.\n";
    return true;
}

string Login::Hashing(const string& Password)
{
    // A simple hashing algorithm: each character plus 4 and multiply by 5

    string hashedPassword ;
    for (char c : Password)
    {
        char hashedChar = (c + 4) * 5;  // Plus 4 and multiply by 5
        hashedPassword += hashedChar;
    }

    return hashedPassword;
}
bool Login::checkUserName(const string & UserName)
{
    if (Login::lg_AllAccounts.contains(UserName))
    {
        cout<<" this UserName is exist please choose another \n";
        return false;
    }
    else 
    {
        return true;
    }
}
// this class does not need Dehashing 
// onlly we need 
/**string Login::DeHashing(const string& HashedPassword)
{
    // De-hashing algorithm: divide each character by 5 and minus 4

    string originalPassword;
    for (char c : HashedPassword)
    {
        char originalChar = (c / 5) - 4;  // Divide by 5 and minus 4
        originalPassword += originalChar;
    }

    return originalPassword;
}**/
// this for debuging 
//int main ()
//{
  //  Login login ("Erfan ", "123455t66");
    //return 0 ;
//}
string Login::get_UserName()
{
    return lg_UserName;
}
string Login::get_HPassword()
{
    return lg_HashedPassword;
}
bool Login::change_Password()
{
    string userName , Password ;
    cout<<" You must first Authenticate your account \n";
   // cout<<" Enter your UserName :\n "
    ///cin>>userName;
    userName = this->get_UserName();
    cout<<"Enter Your Password : \n";
    cin>>Password;
    if (this->Authenticate(userName,Password))
    {
        lg_HashedPassword = Hashing(Password);
        lg_AllAccounts[lg_UserName]["Password"] = lg_HashedPassword;
        return true;
    }
    else 
    {
        cout<<" Your authenticate is not correct \n";
        return false;
    }
}
void Login::ReloadFile()
{
    if (lg_AllAccounts.is_null())
    {   //cout<<"check null if ";
        ifstream AllAccountsFILE("./AllAccountsFILE.json",std::ios::app);
        if (AllAccountsFILE.is_open())//AllAccountsFILE.good())
        {   //cout<<"check good if ";
            //cout<<"buffer : " <<AllAccountsFILE.rdbuf();
            auto lg_AllAccounts = json::parse(AllAccountsFILE);
            AllAccountsFILE.close();
        }
    }
}
int main ()
{
    Login::ReloadFile();

    Login User1("Erfan","Erf@n1382");
    User1.Authenticate("Erfan","Erf@n1382");
    //Login User2("Mohammd","21342");
   // User2.Authenticate("Mohammad","21342");
    return 0;
}