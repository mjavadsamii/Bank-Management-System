#include "Employee.h"
#include <iostream>


static map<string , Employee * > em_AllEmployees;

Employee::Employee(std::string name, std::string family, int ID)
    : UserInfo(name , family , ID) {

        em_AllEmployees[this->get_LoginInfo()->get_UserName()] = this;
}

Employee::Employee(): UserInfo(" " , " " , 0) {

        em_AllEmployees[this->get_LoginInfo()->get_UserName()] = this;
}


std::string Employee::getName() {
    return name;
}

std::string Employee::getFamily() {
    return family;
}

int Employee::getID() {
    return ID;
}

void Employee::addCustomer(Customer& customer) {
    Customer::All_Customers[customer.get_UserName()] = &customer;
    std::cout << "Customer added successfully." << std::endl;
}

void Employee::removeCustomer(const Customer& customer) {

    if (Customer::All_Customers.find(customer.get_UserName())!= Customer::All_Customers.end()) {
        Customer::All_Customers.erase(customer.get_UserName());
        std::cout << "Customer : "<<customer.get_Name()<<"removed successfully." << std::endl;
    } else {
        std::cout << "Customer :  "<<customer.get_Name()<<" not found." << std::endl;
    }
}

void Employee::displayCustomers() {

    std::cout << "Customer List:" << std::endl;
    for (auto& iterator : Customer::All_Customers) {
        std::cout << "Name: " << iterator.second->get_Name() <<"Family : "<<iterator.second->get_Family() <<", ID: " << iterator.second->get_ID() << std::endl;
    }
}

void Employee::displayCustomerAccounts( Customer& customer) {
    std::cout << "Accounts of Customer " << customer.get_Name()<<" "<<customer.get_Family() << ":" << std::endl;

    for ( auto& account : customer.accessibleAccounts) {
        std::cout << "Account Number: " << account->get_accountNum() << ", Balance: " << account->get_balance() << std::endl;
    }
}
//instance of this we better to define this 
/**
void Employee::performTransaction(Account& fromAccount, Account& toAccount, double amount) {
    // Implement the logic for performing a transaction between accounts
    if (fromAccount.getBalance() >= amount) {
        fromAccount.setBalance(fromAccount.getBalance() - amount);
        toAccount.setBalance(toAccount.getBalance() + amount);
        std::cout << "Transaction successful." << std::endl;
    } else {
        std::cout << "Insufficient funds for the transaction." << std::endl;
    }
}
**/
void Transfer_Money(Account& fromAccount, Account& toAccount, double amount)
{
    if (fromAccount.get_balance() >= amount) {
        fromAccount.withdraw(amount);
        toAccount.deposit(amount);
        std::cout << "Transaction successful." << std::endl;
    } else {
        std::cout << "Insufficient funds for the transaction." << std::endl;
    }
}
void Employee::Deposit_Money (Account& toAccount, double amount)
{
    toAccount.deposit(amount);
}
void Pick_Up_Money (Account& fromAccount, double amount)
{
    if (fromAccount.get_balance() >= amount) {
        fromAccount.withdraw(amount);
        std::cout << "Transaction successful." << std::endl;
    } else {
        std::cout << "Insufficient funds for the transaction." << std::endl;
    }
}


void Employee::approveLoanRequest(Loan& loan)
 {
    // Implement the logic for approving or rejecting a z request
    // Update the status of the loan accordingly
    loan.Employee_verifying(this);
    std::cout << "Loan request approved by: " <<this->get_Name()<<" "<<this->get_Family()<<std::endl;
}

void Employee::getAccountStatus(const Account& account) {
    // Implement the logic for getting the status of an account
    std::cout << "Account Status:";
    if ( account.get_status() == true)
    {
         std::cout<<"Active "<< std::endl;
    }
     if ( account.get_status() == false)
    {
         std::cout<<"DisActive"<< std::endl;
    }
    
    std::cout<<"Account Type : "<<account.get_type()<<std::endl;
    std::cout << "Account Number: " << account.get_accountNum() << std::endl;
    std::cout << "Balance: " << account.get_balance() << std::endl;
}

void Employee::addAccountToCustomer(Customer& customer) 
{
    // Implement the logic for adding an account to a customer
    Account* NewAccount = new Account(customer);
    customer.addAccessibleAccount(NewAccount);
    std::cout << "Account added to the customer successfully." << std::endl;
}

void Employee::removeAccountFromCustomer(Account & account) 
{
    // Implement the logic for removing an account from a customer
    (account.get_customer())->removeAccessibleAccount(&account);
    std::cout << "Account removed from the customer successfully." << std::endl;
}


void Employee::displayCustomerAccountTransactions(Customer& customer)
 {
    for ( auto iterator : customer.accessibleAccounts)
    {
        std::cout << "Transactions of Account " << (*iterator).get_accountNum() << " for Customer " << customer.get_Name()<<" "<<customer.get_Family() << ":" << std::endl;
        customer.viewAccountTransactions(*iterator);
    }
}
void Employee::verify_Customer (Customer & customer )
{
    customer.Verify();
}
void Employee::discredit_Customer(Customer & customer )
{
    customer.Discredit();
}
