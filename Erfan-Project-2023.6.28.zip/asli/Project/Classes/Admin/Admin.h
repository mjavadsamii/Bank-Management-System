#ifndef ADMIN_H
#define ADMIN_H

#include <vector>
#include <map> // using map is better store a all Admin by its username 
#include "../Employee/Employee.h"
//#include "../Customer/Customer.h"
//#include "../Account/Account.h"
//#include "../Loan/Loan.h"
//#include "../Transaction/Transaction.h"
#include "../UserInfo/UserInfo.h"
using std::map;

class Admin : public UserInfo {
private:

public:
    static map <string , Admin *> ad_AllAdmins; 
    // Constructors
    Admin(std::string name, std::string family, int ID);

    // Employee management
    void ad_addEmployee( Employee& employee);
    void ad_removeEmployee(const Employee& employee);
    void ad_updateEmployee( Employee& employee);
    void ad_EditEmployees(Employee & employee);

    // Customer management
    void ad_addCustomer(Customer& customer);
    void ad_removeCustomer(const Customer& customer);
    void ad_updateCustomer(Customer& customer);
    void ad_searchCustomers(string Name , string Family );

    // Account management
    void ad_addAccount(Customer & customer );
    void ad_removeAccount(Account& account);
    void ad_updateAccount(const Account& account);

    // Loan management
    //void ad_addLoan(const Loan& loan);
    bool ad_confirm_loan(Loan & loan);
    void ad_removeLoan( Loan& loan);
    void ad_updateLoan(const Loan& loan);

    // Transaction management
    void ad_addTransaction(const Transaction& transaction);
    void ad_updateTransaction(const Transaction& transaction);

    // Search functions
    void ad_searchEmployees();
    void ad_searchCustomers();
    void ad_searchTransactions(int TransactionID) ;
    void ad_searchLoans();

    // Other functions
    void ad_displayMenu();
    void viewAccountTransactions(Account account) const;
};

#endif
