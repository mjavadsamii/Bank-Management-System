#ifndef JONINFO_H
#define JONINFO_H

class JobInfo 
{
    private :
        int ji_TimeOfWork;
        int ji_Salay;
    public :
        JobInfo();//int TimeOfWork , int Salary )
        // another function that we need 
        // and also getter and setter 
        // we should to define that in .cpp 
        int set_Time(int Time);
        int set_Salary(int Salary);
        int get_Time();
        int get_Salary();
};

#endif